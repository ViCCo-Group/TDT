% function cfg = decoding_defaults(cfg)
%
% Function where all defaults are declared and paths are set for decoding
% toolbox.
%
% Usage:
%  cfg = decoding_defaults
%       Get all decoding defaults (OVERWRITES cfg)
%
%  cfg = decoding_defaults(cfg)
%       Puts default values to all fields that are not defined in the
%       passed cfg (UPDATES cfg).

% Martin H. 2011/03

% HISTORY
% MARTIN, 11/12/18
%   added self-referencing function to add values from defaults to cfg that
%   have not been set manually
% KAI, 11/07/01
%   wrap-around correction and cfg.searchlight.wrap_control added

function cfg = decoding_defaults(cfg)

if ~exist('cfg','var'), cfg = struct; end

%% Add paths
% to this decoding toolbox
% will be determined automatically from the position of this file
fname = mfilename('fullpath');
fpath = fileparts(fname);
addpath(genpath(fpath));
defaults.toolbox_path = fpath;

% path to libSVM (set if version delivered with this package is not working)
% addpath('/analysis/share/software/matlab_libraries/libsvm-3.11')

%% Set defaults

% General values
defaults.verbose = 1; % Verbosity (0 to 2)
defaults.testmode = 0; % Test mode off
defaults.analysis = 'searchlight'; % standard analysis
defaults.software = 'SPM8'; % what software to use to access brain images

% specification of scaling
defaults.scale.method = 'none';
defaults.scale.estimation = 'none';
defaults.scale.cutoff = [-inf inf];

% Specification of feature selection
defaults.feature_selection.method = 'none';

% Specification of parameter selection
defaults.parameter_selection.method = 'none';

% Searchlight specific defaults
defaults.searchlight.unit = 'voxels'; % searchlight unit ('mm' or 'voxels')
defaults.searchlight.radius = 4; % 4 voxels is a standard often used
defaults.searchlight.spherical = 0;
defaults.searchlight.wrap_control = 1; % tests that no wrap-around effects occur when searchlight is shifted. Only switch off when you are sure that your brain is not near the boarder and when you need even more speed (the check is extremely fast, though).

% Decoding specific values
defaults.decoding.method = 'classification'; % classification as standard
defaults.decoding.software = 'libsvm'; % libsvm as a standard
% parameters (in defaults for libsvm)
defaults.decoding.train.classification.model_parameters = '-s 0 -t 0 -c 1 -b 0 -q'; % linear classification
defaults.decoding.train.regression.model_parameters = '-s 4 -t 0 -c 1 -n 0.5 -b 0 -q'; % nu-SVR (adapt cost to control speed)
defaults.decoding.test.classification.model_parameters = '-q';
defaults.decoding.test.regression.model_parameters = '-q';

% warning('No unit for searchlight provided. Assuming voxels...') #ok<WNTAG>
% TODO: move this warning somewhere else (best in function where we can
% check if it was overwritten, or better provide an output with verbose = 1
% that mm is assumed together with the number of voxels in the searchlight

% Results specific defaults
defaults.results.output = {'accuracy_minus_chance'};
defaults.results.write = 1; % write results
defaults.results.overwrite = 0; % don't overwrite existing results
defaults.results.setwise = 0; % return results of each decoding set separately
defaults.results.filestart = 'res';
defaults.results.dir = fullfile(fpath,'decoding_results');

%% Add values to cfg that have not yet been set

cfg = assign_fields(defaults,cfg);


%==============================================
function cfg = assign_fields(defaults,cfg)

% Self-referencing function that goes through all field names and adds 
% non-existent fields to cfg from the defaults.

d_fields = fieldnames(defaults);

for i = 1:size(d_fields,1)
    % If there are no subfields in the current field
    if ~isstruct(defaults.(d_fields{i}))
        % If this field doesn't exist in cfg, add it from defaults
        if ~isfield(cfg,d_fields{i})
            cfg.(d_fields{i}) = defaults.(d_fields{i});
        end
    % If there are subfields in the current field
    else
        % If this field doesn't exist in cfg, add it (and all subfields) from defaults
        if ~isfield(cfg,d_fields{i})
            cfg.(d_fields{i}) = defaults.(d_fields{i});
        % Else loop through function again for all subfields    
        else
            cfg.(d_fields{i}) = assign_fields(defaults.(d_fields{i}),cfg.(d_fields{i}));
        end
    end
end