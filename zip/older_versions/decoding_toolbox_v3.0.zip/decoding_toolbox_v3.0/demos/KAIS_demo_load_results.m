% Example

clear all
close all

%% Do a computation

% DO THIS AND CHECK WHETHER IT IS NOW SLOWER THAN BEFORE (and where)
KAIS_demo1_decoding_tutorial_filled;
% Example time running: 00:02:30
% Results: /Users/kai/Documents/!Projekte/Decoding_Toolbox/testdata/results/buttonpress_onehand1

%% load the cfg of a decoding that you run, e.g.
loaded_cfg = load('/Users/kai/Documents/!Projekte/Decoding_Toolbox/testdata/results/buttonpress_onehand1/res_cfg');
cfg = loaded_cfg.cfg
org_cfg = cfg; % save if needed later
clear loaded_cfg

%% Read result data and prepare it to calculate a new transformation

% The following call will 
% - load all result data that was produced by the cfg (returned as result)
% and prepare recomputing new result transformations by
% - Updating CFG:
%   - setting cfg.decoding.use_loaded_results = 1
%   - modify  cfg.result.dir so that executing the new cfg will write 
%     results in a subfolder of the original directory (to avoid 
%     overwritting old results)
% - Creating passed_data that needs to be passed to decoding
[results, cfg, passed_data] = read_resultdata(cfg);
org_results = results; % save if needed later

%% Specify what you like to compute, and redo the computation

% use same transformations so we can compare the results
cfg.results.output = org_cfg.results.output; % simply compute all again, but without redoing the decoding

% do decoding (without decoding ;)
[results, cfg] = decoding(cfg, passed_data);

% time running: 00:02:08  <-- not much faster in this case, but a bit
%
% because calculation was fast anyway. If it turns out to be always slow, 
% might need some profiling / optimization.
%
% Results:
% /Users/kai/Documents/!Projekte/Decoding_Toolbox/testdata/results/buttonpress_onehand1/transres_from_saved_results_20143107
%
% Results are identical.
%
% The current implementation is very close to the original calculation, so
% it should pretty much not produce any errors. However, it could be much
% faster, if we would trust more that the data did not change etc. I would
% at the moment leave it like it is, and see whether it really is slow for
% computations that were originally time consuming /& optimize the current
% code.